### Podstawowa funkcja "Welcome":

```JavaScript
function Welcome(){
    return(
    <h1>Witaj Heniu</h1>
    )
}
export default Welcome
```

[[Przekazanie Funkcji do App.jsx]]
[[Zmienne przekazywane do funkcji]]
