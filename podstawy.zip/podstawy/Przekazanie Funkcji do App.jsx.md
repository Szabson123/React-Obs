```JS
import Welcome from './components/Welcome'

function App() {
  return(
  <div>
    <Welcome/>
  </div>
  )
}
export default App

```
