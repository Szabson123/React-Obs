Tworzymy folder component w folderze /src

W nim nasz pierwszy component np. "Welcome":

![[Pasted image 20250425184157.png]]

[[Funkcje]]
