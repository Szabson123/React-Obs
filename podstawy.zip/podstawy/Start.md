### Żeby wystartować nowy projekt w React należy uźyć komend:

```
npm create vite@latest
```

#### Dodajemy nazwę projektu:

![[Pasted image 20250425183516.png]]

#### Wybieramy package json Reacta framework i variant np. jsx:

![[Pasted image 20250425183629.png]]

#### Następnie 3 kolejne komendy:

```
  cd Trening2
  npm install
  npm run dev
```

[[Tworzenie Komponentu]]
[[Funkcje]]
[[Błędy]]
